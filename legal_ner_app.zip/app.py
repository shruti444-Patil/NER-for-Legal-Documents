import streamlit as st
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Input, Embedding, Bidirectional, LSTM, Dense, TimeDistributed, Conv1D, GlobalMaxPooling1D, Concatenate
from tensorflow.keras.models import Model
from sklearn.model_selection import train_test_split
from seqeval.metrics import f1_score, classification_report
import nltk
nltk.download('punkt', quiet=True)

def tokenize_text(text):
    return nltk.word_tokenize(text)

def load_dummy_data():
    sentences = [["The", "court", "found", "John", "guilty"],
                 ["Mary", "signed", "the", "contract"]]
    tags = [["O", "O", "O", "PERSON", "O"],
            ["PERSON", "O", "O", "LEGAL_DOC"]]
    return sentences, tags

def build_vocab(seqs):
    vocab = {w for s in seqs for w in s}
    word2idx = {w: i + 2 for i, w in enumerate(vocab)}
    word2idx["<PAD>"] = 0
    word2idx["<UNK>"] = 1
    idx2word = {i: w for w, i in word2idx.items()}
    return word2idx, idx2word

def build_tag_vocab(tags):
    vocab = {t for s in tags for t in s}
    tag2idx = {t: i for i, t in enumerate(sorted(vocab))}
    idx2tag = {i: t for t, i in tag2idx.items()}
    return tag2idx, idx2tag

def encode_data(sentences, tags, word2idx, tag2idx, max_len=20):
    X, y = [], []
    for s, t in zip(sentences, tags):
        w_ids = [word2idx.get(w, 1) for w in s]
        t_ids = [tag2idx[ti] for ti in t]
        if len(w_ids) < max_len:
            w_ids.extend([0] * (max_len - len(w_ids)))
            t_ids.extend([tag2idx['O']] * (max_len - len(t_ids)))
        else:
            w_ids = w_ids[:max_len]
            t_ids = t_ids[:max_len]
        X.append(w_ids)
        y.append(t_ids)
    return np.array(X), np.array(y)

def build_model(vocab_size, tag_size, max_len=20, emb_dim=64):
    input_word = Input(shape=(max_len,))
    emb = Embedding(input_dim=vocab_size, output_dim=emb_dim, mask_zero=True)(input_word)

    cnn = Conv1D(filters=32, kernel_size=3, padding="same", activation="relu")(emb)
    cnn = GlobalMaxPooling1D()(cnn)

    repeated = tf.keras.layers.RepeatVector(max_len)(cnn)
    merged = Concatenate()([emb, repeated])

    x = Bidirectional(LSTM(units=64, return_sequences=True))(merged)
    x = TimeDistributed(Dense(tag_size, activation="softmax"))(x)

    model = Model(input_word, x)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model

st.title("📑 Legal Document NER — CNN + RNN")

menu = ["Train Model", "Test Model", "Extract from Document"]
choice = st.sidebar.radio("Navigate", menu)

if "model" not in st.session_state:
    st.session_state.model = None
    st.session_state.word2idx = None
    st.session_state.idx2tag = None

if choice == "Train Model":
    st.header("⚙️ Train NER Model")
    sentences, tags = load_dummy_data()
    word2idx, idx2word = build_vocab(sentences)
    tag2idx, idx2tag = build_tag_vocab(tags)

    X, y = encode_data(sentences, tags, word2idx, tag2idx)
    y = np.expand_dims(y, -1)

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2)

    model = build_model(len(word2idx), len(tag2idx))
    model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=5, batch_size=2)

    st.session_state.model = model
    st.session_state.word2idx = word2idx
    st.session_state.idx2tag = idx2tag

    st.success("✅ Model trained successfully!")

elif choice == "Test Model":
    st.header("🧪 Evaluate Model")
    if st.session_state.model is None:
        st.warning("Please train the model first.")
    else:
        sentences, tags = load_dummy_data()
        X, y = encode_data(sentences, tags, st.session_state.word2idx, {v:k for k,v in st.session_state.idx2tag.items()})
        y = np.expand_dims(y, -1)
        preds = st.session_state.model.predict(X)
        preds = np.argmax(preds, axis=-1)
        true = y.squeeze()

        pred_tags = [[st.session_state.idx2tag[i] for i in row] for row in preds]
        true_tags = [[st.session_state.idx2tag[i] for i in row] for row in true]

        f1 = f1_score(true_tags, pred_tags)
        st.write("F1 Score:", round(f1, 2))
        st.text(classification_report(true_tags, pred_tags))

elif choice == "Extract from Document":
    st.header("📂 Upload Legal Document for Entity Extraction")
    if st.session_state.model is None:
        st.warning("Please train the model first.")
    else:
        uploaded = st.file_uploader("Upload a text file", type=["txt"])
        if uploaded is not None:
            text = uploaded.read().decode("utf-8")
            tokens = tokenize_text(text)
            X, _ = encode_data([tokens], [["O"] * len(tokens)], st.session_state.word2idx, {v:k for k,v in st.session_state.idx2tag.items()})
            preds = st.session_state.model.predict(X)
            preds = np.argmax(preds, axis=-1)[0]
            entities = [(tok, st.session_state.idx2tag[preds[i]]) for i, tok in enumerate(tokens)]

            st.subheader("Extracted Entities:")
            for tok, tag in entities:
                if tag != 'O':
                    st.markdown(f"**{tok}** → {tag}")